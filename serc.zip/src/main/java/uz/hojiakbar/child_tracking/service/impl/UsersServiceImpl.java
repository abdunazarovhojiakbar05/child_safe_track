package uz.hojiakbar.child_tracking.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uz.hojiakbar.child_tracking.dto.parentDto.*;
import uz.hojiakbar.child_tracking.dto.response.ActivitySummaryResponseDto;
import uz.hojiakbar.child_tracking.dto.response.AlertResponseDto;
import uz.hojiakbar.child_tracking.dto.response.GeofenceResponseDto;
import uz.hojiakbar.child_tracking.dto.response.LocationResponseDto;
import uz.hojiakbar.child_tracking.entity.*;
import uz.hojiakbar.child_tracking.enums.Alert_Severity;
import uz.hojiakbar.child_tracking.enums.Alert_Type;
import uz.hojiakbar.child_tracking.enums.Geofences_Type;
import uz.hojiakbar.child_tracking.enums.Status;
import uz.hojiakbar.child_tracking.exception.ResourceNotFoundException;
import uz.hojiakbar.child_tracking.repository.ChildRepository;
import uz.hojiakbar.child_tracking.repository.DeviceRepository;
import uz.hojiakbar.child_tracking.repository.FamilyRelationsRepository;
import uz.hojiakbar.child_tracking.repository.UsersRepository;
import uz.hojiakbar.child_tracking.security.CustomUserDetails;
import uz.hojiakbar.child_tracking.service.UsersService;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UsersServiceImpl implements UsersService {


    private final UsersRepository usersRepository;
    private final ChildRepository childRepository;
    private final FamilyRelationsRepository familyRepository;
    private final Random random = new Random();
    private final DeviceRepository deviceRepository;


    @Override
    public ParentDashboardResponseDto getParentDashboard(String emailUser) {

        String email =   emailUser ;

        SummaryResponseDto summary = new SummaryResponseDto();
        summary.setActiveChildren(activeChildren(email));
        summary.setTotalAlertsToday(3);
        summary.setUnreadAlerts(2);

        List<ChildDashboardDto> children = new ArrayList<>();                                 /////
        List<GeofenceResponseDto> geofences = new ArrayList<>();                             /////
        List<ActivitySummaryResponseDto> dailyActivitySummary = new ArrayList<>();          /////
        List<AlertResponseDto> recentAlerts = new ArrayList<>();                           /////

/// -------------------------------------------------------------------------------------------
        LocationResponseDto location = new LocationResponseDto();
        Address address = new Address("Toshkent", "Sergeli");
        location.setAddress(address);
        location.setLatitude(BigDecimal.valueOf(234.3456));
        location.setLongitude(BigDecimal.valueOf(345.3456));
         location.setCreatedAt(LocalDateTime.now());


/// --------------------------------------------------
        GeofenceResponseDto geofence = new GeofenceResponseDto();
        geofence.setId(UUID.randomUUID());
        geofence.setName("xali");
        geofence.setType(Geofences_Type.SAFE);
///-------------------------------------------------------------


        ActivitySummaryResponseDto activitySummary = new ActivitySummaryResponseDto();
        activitySummary.setDistance(2345D);
        activitySummary.setPlacesVisited(2342D);
        activitySummary.setScreenTimeMin(341);

///-----------------------------------------------------------------------

        AlertResponseDto alert = new AlertResponseDto();
        alert.setId(UUID.randomUUID());
        alert.setTitle("pul kerak");
        alert.setType(Alert_Type.DEVICE_OFFLINE);
        alert.setCreated_at(LocalDateTime.now());
        alert.setSeverity(Alert_Severity.WARNING);


///-----------------------------------------------------------------------------------------
        children.add(new ChildDashboardDto(
                UUID.randomUUID(),
                "Kimsanov  Hoshim",
                "xali url yoq",
                true,
                34,
                false,
                location,
                geofence,
                activitySummary
        ));

        geofences.add(geofence);
        dailyActivitySummary.add(activitySummary);
        recentAlerts.add(alert);




        return new ParentDashboardResponseDto(summary, children, geofences, dailyActivitySummary, recentAlerts);
    }




    private int activeChildren(String email) {
            Users user = usersRepository.findByEmail(email);
            if(user == null){
                throw new ResourceNotFoundException("User not found with email: " + email);
            }
            return user.getChildren().size();
    }

















    @Override
    @Transactional(readOnly = true)
    public List<ChildListResponseDto> getChildrenByParentEmail(String email) {


        List<Family_Relations> list = familyRepository.findByParentEmail(email);

        if(list.isEmpty()){
            throw new ResourceNotFoundException("xali farszandingiz yoq");
        }

        return list.stream()
                .filter(relation -> relation.getChild() != null)
                .map(relation -> {
                    Child child = relation.getChild();
                    return ChildListResponseDto.builder()
                            .id(child.getId())
                            .full_name(child.getFull_name())
                            .phone(child.getPhone())
                            .avatar_url(child.getAvatar_url())
                            .date_of_birth(child.getDate_of_birth())
                            .verified(child.getVerified())
                            .age(random.nextInt(10, 18))
                            .build();
                }).toList();
    }

    @Override
    public void save(Users parent) {
        usersRepository.save(parent);
    }

    @Override
    public ChildDashboardResponseDto getChildById(UUID childId, CustomUserDetails userDetails) {
        Child child = childRepository.findById(childId).orElseThrow(() -> new ResourceNotFoundException("child not found"));

        if(child == null ){
            throw new ResourceNotFoundException("child not found");
        }

        if(userDetails.getUsers() == null){
            throw new ResourceNotFoundException("parent not found");
        }

        //Device device = deviceRepository.findByChildId(childId).orElseThrow(() -> new ResourceNotFoundException("device not found"));

        return new ChildDashboardResponseDto();

    }


}

