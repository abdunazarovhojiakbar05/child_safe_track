package uz.hojiakbar.child_tracking.dto.request;

public class ChildRequestDto {
}
