package uz.hojiakbar.child_tracking.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class REQHeader {

    private String deviceId;

}
