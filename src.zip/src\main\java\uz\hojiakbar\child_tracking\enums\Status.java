package uz.hojiakbar.child_tracking.enums;

public enum Status {

    PENDING,
    ACTIVE,
    BLOCKED,
    ACCEPTED

}
