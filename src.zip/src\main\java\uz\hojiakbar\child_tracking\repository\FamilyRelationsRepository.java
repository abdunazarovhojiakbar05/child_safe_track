package uz.hojiakbar.child_tracking.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import uz.hojiakbar.child_tracking.entity.Family_Relations;
import uz.hojiakbar.child_tracking.entity.Users;
import java.util.Optional;
import java.util.UUID;

public interface FamilyRelationsRepository extends JpaRepository<Family_Relations, UUID> {

    @org.springframework.data.jpa.repository.Query("select f from family_relations f where f.invite_code = :inviteCode")
    Optional<Family_Relations> findByInvite_code(String inviteCode);

}
