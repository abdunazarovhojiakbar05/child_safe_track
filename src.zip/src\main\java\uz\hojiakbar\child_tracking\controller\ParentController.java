package uz.hojiakbar.child_tracking.controller;


import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.hojiakbar.child_tracking.dto.auth.EmailDto;
import uz.hojiakbar.child_tracking.dto.parentDto.ChildListResponseDto;
import uz.hojiakbar.child_tracking.dto.parentDto.ParentDashboardResponseDto;
import uz.hojiakbar.child_tracking.service.FamilyRelationsService;
import uz.hojiakbar.child_tracking.service.UsersService;

@RestController
@RequestMapping("/api/v1/parent")
@RequiredArgsConstructor
public class ParentController {

    private final UsersService parentService;
    private final FamilyRelationsService relationService;


    @GetMapping
    @Operation(summary = "parent tomon uchun dashboard")
    public ResponseEntity<ParentDashboardResponseDto> getParents() {

        return ResponseEntity.ok(parentService.getParentDashboard());

    }


    @PostMapping("/generate-invite-code")
    @Operation(summary = "Bola ulanishi uchun 8 xonali kod yaratish")
    public ResponseEntity<String> generateInviteCode(@RequestBody EmailDto email) {

        String code = relationService.generateInviteCode(email);

        return ResponseEntity.ok(code);
    }

    @GetMapping("/children")
    @Operation(summary = "Ota-onani bollari ro'yxati")
    public ResponseEntity<ChildListResponseDto> getChildren(@RequestBody EmailDto email) {

        return ResponseEntity.ok(parentService.getChildrenByParentEmail(email.getEmail()));

    }

}
