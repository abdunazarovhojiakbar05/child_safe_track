package uz.hojiakbar.child_tracking.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import uz.hojiakbar.child_tracking.entity.Child;
import uz.hojiakbar.child_tracking.entity.Users;
import uz.hojiakbar.child_tracking.repository.ChildRepository;
import uz.hojiakbar.child_tracking.repository.UsersRepository;
import uz.hojiakbar.child_tracking.service.UserDetailsService;

import java.util.Collections;

@Service
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UsersRepository usersRepository;
    private final ChildRepository childRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Users user = usersRepository.findByEmail(username);
        if (user != null) {
            return org.springframework.security.core.userdetails.User.builder()
                    .username(user.getEmail())
                    .password(user.getPassword_hash() != null ? user.getPassword_hash() : "")
                    .authorities(user.getRole().name())
                    .build();
        }

        Child child = childRepository.findByPhone(username);
        if (child != null) {
            return org.springframework.security.core.userdetails.User.builder()
                    .username(child.getPhone())
                    .password(child.getPassword_hash() != null ? child.getPassword_hash() : "")
                    .authorities("CHILD")
                    .build();
        }

        throw new UsernameNotFoundException("Foydalanuvchi topilmadi: " + username);
    }
}