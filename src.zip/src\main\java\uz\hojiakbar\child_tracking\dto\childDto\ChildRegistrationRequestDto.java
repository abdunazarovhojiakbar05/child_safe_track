package uz.hojiakbar.child_tracking.dto.childDto;

public class ChildRegistrationRequestDto {

    String inviteCode;

    String name;

    String fullName;
}
