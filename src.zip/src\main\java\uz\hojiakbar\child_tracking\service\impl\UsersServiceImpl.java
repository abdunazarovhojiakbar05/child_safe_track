package uz.hojiakbar.child_tracking.service.impl;

import org.springframework.stereotype.Service;
import uz.hojiakbar.child_tracking.dto.parentDto.ChildDashboardDto;
import uz.hojiakbar.child_tracking.dto.parentDto.ChildListResponseDto;
import uz.hojiakbar.child_tracking.dto.parentDto.ParentDashboardResponseDto;
import uz.hojiakbar.child_tracking.dto.parentDto.SummaryResponseDto;
import uz.hojiakbar.child_tracking.dto.response.ActivitySummaryResponseDto;
import uz.hojiakbar.child_tracking.dto.response.AlertResponseDto;
import uz.hojiakbar.child_tracking.dto.response.GeofenceResponseDto;
import uz.hojiakbar.child_tracking.dto.response.LocationResponseDto;
import uz.hojiakbar.child_tracking.entity.Address;
import uz.hojiakbar.child_tracking.entity.Child;
import uz.hojiakbar.child_tracking.entity.Users;
import uz.hojiakbar.child_tracking.enums.Alert_Severity;
import uz.hojiakbar.child_tracking.enums.Alert_Type;
import uz.hojiakbar.child_tracking.enums.Geofences_Type;
import uz.hojiakbar.child_tracking.repository.UsersRepository;
import uz.hojiakbar.child_tracking.service.UsersService;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class UsersServiceImpl implements UsersService {


    private final UsersRepository usersRepository;

    public UsersServiceImpl(UsersRepository usersRepository) {
        this.usersRepository = usersRepository;
    }



    @Override
    public ParentDashboardResponseDto getParentDashboard() {

        SummaryResponseDto summary = new SummaryResponseDto();
        summary.setActiveChildren(1L);
        summary.setTotalAlertsToday(3L);
        summary.setUnreadAlerts(2L);

        List<ChildDashboardDto> children = new ArrayList<>();                                 /////
        List<GeofenceResponseDto> geofences = new ArrayList<>();                             /////
        List<ActivitySummaryResponseDto> dailyActivitySummary = new ArrayList<>();          /////
        List<AlertResponseDto> recentAlerts = new ArrayList<>();                           /////

/// -------------------------------------------------------------------------------------------
        LocationResponseDto location = new LocationResponseDto();
        Address address = new Address("Toshkent", "Sergeli");
        location.setAddress(address);
        location.setLatitude(BigDecimal.valueOf(234.3456));
        location.setLongitude(BigDecimal.valueOf(345.3456));
        location.setCratedAt(LocalDateTime.now());


/// --------------------------------------------------
        GeofenceResponseDto geofence = new GeofenceResponseDto();
        geofence.setId(UUID.randomUUID());
        geofence.setName("xali");
        geofence.setType(Geofences_Type.SAFE);
///-------------------------------------------------------------


        ActivitySummaryResponseDto activitySummary = new ActivitySummaryResponseDto();
        activitySummary.setDistance(2345D);
        activitySummary.setPlacesVisited(2342D);
        activitySummary.setScreenTimeMin(341);

///-----------------------------------------------------------------------

        AlertResponseDto alert = new AlertResponseDto();
        alert.setId(UUID.randomUUID());
        alert.setTitle("pul kerak");
        alert.setType(Alert_Type.DEVICE_OFFLINE);
        alert.setCreated_at(LocalDateTime.now());
        alert.setSeverity(Alert_Severity.WARNING);


        ///-----------------------------------------------------------------------------------------
        children.add(new ChildDashboardDto(
                UUID.randomUUID(),
                "Kimsanov  Hoshim",
                "xali url yoq",
                true,
                34,
                false,
                location,
                geofence,
                activitySummary
        ));

        geofences.add(geofence);
        dailyActivitySummary.add(activitySummary);
        recentAlerts.add(alert);


        return new ParentDashboardResponseDto(summary, children, geofences, dailyActivitySummary, recentAlerts);
    }

    @Override
    public  ChildListResponseDto getChildrenByParentEmail(String email) {
        // 1. Ota-onani emaildan qidiramiz
        Users parent = usersRepository.findByEmail(email);

        if (parent == null) {
            throw new RuntimeException("Foydalanuvchi topilmadi!");
        }

        // 2. Ota-onaning bolalarini oddiy ro'yxat qilib olamiz
        List<Child> childrenList = new ArrayList<>(parent.getChildren());

        // 3. Bittagina DTO yaratamiz va ichiga butun ro'yxatni joylaymiz
        return ChildListResponseDto.builder()
                .child(childrenList)
                .build();
    }
}

